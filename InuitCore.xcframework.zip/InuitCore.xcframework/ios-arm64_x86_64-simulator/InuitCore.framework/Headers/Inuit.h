//
//  Inuit.h
//  Inuit
//
//  Created by Sašo Sečnjak on 31/08/16.
//  Copyright © 2016 Inova. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for Inuit.
FOUNDATION_EXPORT double InuitVersionNumber;

//! Project version string for Inuit.
FOUNDATION_EXPORT const unsigned char InuitVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <Inuit/PublicHeader.h>


